import { useState } from "react";
import { SmartLockHome } from "./components/SmartLockHome";
import { LockControl } from "./components/LockControl";

export default function App() {
  const [selectedLocation, setSelectedLocation] = useState<
    "windows" | "front-door" | "back-door" | null
  >(null);

  const [lockStates, setLockStates] = useState({
    windows: true,
    "front-door": true,
    "back-door": true,
  });

  const handleLockChange = (
    location: "windows" | "front-door" | "back-door",
    isLocked: boolean
  ) => {
    setLockStates((prev) => ({ ...prev, [location]: isLocked }));
  };

  return (
    <div className="size-full">
      {selectedLocation ? (
        <LockControl
          location={selectedLocation}
          isLocked={lockStates[selectedLocation]}
          onLockChange={(isLocked) => handleLockChange(selectedLocation, isLocked)}
          onBack={() => setSelectedLocation(null)}
        />
      ) : (
        <SmartLockHome
          onSelectOption={setSelectedLocation}
          lockStates={lockStates}
          onLockAll={(isLocked) =>
            setLockStates({
              windows: isLocked,
              "front-door": isLocked,
              "back-door": isLocked,
            })
          }
        />
      )}
    </div>
  );
}