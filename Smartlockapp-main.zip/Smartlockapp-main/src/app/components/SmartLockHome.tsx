import { Lock, DoorOpen, Grid3x3, ShieldAlert, Unlock } from "lucide-react";

interface SmartLockHomeProps {
  onSelectOption: (option: "windows" | "front-door" | "back-door") => void;
  lockStates: {
    windows: boolean;
    "front-door": boolean;
    "back-door": boolean;
  };
  onLockAll: (isLocked: boolean) => void;
}

export function SmartLockHome({ onSelectOption, lockStates, onLockAll }: SmartLockHomeProps) {
  const options = [
    {
      id: "windows" as const,
      label: "Windows",
      icon: Grid3x3,
    },
    {
      id: "front-door" as const,
      label: "Front Door",
      icon: DoorOpen,
    },
    {
      id: "back-door" as const,
      label: "Back Door",
      icon: Lock,
    },
  ];

  const allLocked = Object.values(lockStates).every((state) => state);
  const allUnlocked = Object.values(lockStates).every((state) => !state);

  const requestNotificationPermission = async () => {
    if ("Notification" in window && Notification.permission === "default") {
      await Notification.requestPermission();
    }
  };

  const sendNotification = (message: string) => {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("Smart Lock", {
        body: message,
        icon: "/favicon.ico",
        badge: "/favicon.ico",
      });
    }
  };

  const handleLockAll = async () => {
    await requestNotificationPermission();
    onLockAll(true);
    sendNotification("All locations locked");
  };

  const handleUnlockAll = async () => {
    await requestNotificationPermission();
    onLockAll(false);
    sendNotification("All locations unlocked");
  };

  const handleAlertPolice = async () => {
    await requestNotificationPermission();
    sendNotification("Police alerted to come to house");

    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance("Police alerted");
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 to-zinc-100 dark:from-zinc-950 dark:to-zinc-900 p-6">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-12 pt-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-500 dark:bg-blue-600 mb-4">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-zinc-900 dark:text-zinc-50 mb-2">
            Smart Lock
          </h1>
          <p className="text-zinc-600 dark:text-zinc-400">
            Choose a location to control
          </p>
        </div>

        <div className="space-y-4 mb-6">
          {options.map((option) => {
            const Icon = option.icon;
            const isLocked = lockStates[option.id];
            return (
              <button
                key={option.id}
                onClick={() => onSelectOption(option.id)}
                className="w-full bg-white dark:bg-zinc-800 rounded-2xl p-6 flex items-center gap-4 shadow-sm hover:shadow-md transition-all active:scale-98 border border-zinc-200 dark:border-zinc-700"
              >
                <div className="w-14 h-14 rounded-xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Icon className="w-7 h-7 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="flex-1 text-left">
                  <span className="text-xl font-semibold text-zinc-900 dark:text-zinc-50 block">
                    {option.label}
                  </span>
                  <span
                    className={`text-sm ${
                      isLocked
                        ? "text-red-600 dark:text-red-400"
                        : "text-green-600 dark:text-green-400"
                    }`}
                  >
                    {isLocked ? "Locked" : "Unlocked"}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        <div className="space-y-3 mb-6">
          {!allLocked && (
            <button
              onClick={handleLockAll}
              className="w-full py-4 rounded-2xl font-semibold text-lg bg-red-500 dark:bg-red-600 text-white hover:bg-red-600 dark:hover:bg-red-700 active:scale-98 shadow-sm transition-all"
            >
              <div className="flex items-center justify-center gap-2">
                <Lock className="w-5 h-5" />
                <span>Lock All</span>
              </div>
            </button>
          )}

          {!allUnlocked && (
            <button
              onClick={handleUnlockAll}
              className="w-full py-4 rounded-2xl font-semibold text-lg bg-green-500 dark:bg-green-600 text-white hover:bg-green-600 dark:hover:bg-green-700 active:scale-98 shadow-sm transition-all"
            >
              <div className="flex items-center justify-center gap-2">
                <Unlock className="w-5 h-5" />
                <span>Unlock All</span>
              </div>
            </button>
          )}
        </div>

        <button
          onClick={handleAlertPolice}
          className="w-full py-4 rounded-2xl font-semibold text-lg bg-orange-500 dark:bg-orange-600 text-white hover:bg-orange-600 dark:hover:bg-orange-700 active:scale-98 shadow-sm transition-all"
        >
          <div className="flex items-center justify-center gap-2">
            <ShieldAlert className="w-5 h-5" />
            <span>Alert Police to Come to House</span>
          </div>
        </button>

        <div className="mt-12 text-center">
          <p className="text-sm text-zinc-500 dark:text-zinc-500">
            Demo app • No real connections
          </p>
        </div>
      </div>
    </div>
  );
}
