import { Lock, Unlock, ChevronLeft } from "lucide-react";
import { motion } from "motion/react";

interface LockControlProps {
  location: "windows" | "front-door" | "back-door";
  isLocked: boolean;
  onLockChange: (isLocked: boolean) => void;
  onBack: () => void;
}

export function LockControl({ location, isLocked, onLockChange, onBack }: LockControlProps) {
  const locationLabels = {
    windows: "Windows",
    "front-door": "Front Door",
    "back-door": "Back Door",
  };

  const locationName = locationLabels[location];

  const requestNotificationPermission = async () => {
    if ("Notification" in window && Notification.permission === "default") {
      await Notification.requestPermission();
    }
  };

  const sendNotification = (message: string) => {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("Smart Lock", {
        body: message,
        icon: "/favicon.ico",
        badge: "/favicon.ico",
      });
    }
  };

  const handleLock = async () => {
    await requestNotificationPermission();
    onLockChange(true);
    sendNotification(`${locationName} locked`);
  };

  const handleUnlock = async () => {
    await requestNotificationPermission();
    onLockChange(false);
    sendNotification(`${locationName} unlocked`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 to-zinc-100 dark:from-zinc-950 dark:to-zinc-900">
      <div className="max-w-md mx-auto min-h-screen flex flex-col">
        <div className="p-6">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-6 pb-12">
          <motion.div
            key={isLocked ? "locked" : "unlocked"}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="mb-12"
          >
            <div
              className={`w-32 h-32 rounded-full flex items-center justify-center shadow-lg transition-colors ${
                isLocked
                  ? "bg-red-500 dark:bg-red-600"
                  : "bg-green-500 dark:bg-green-600"
              }`}
            >
              {isLocked ? (
                <Lock className="w-16 h-16 text-white" />
              ) : (
                <Unlock className="w-16 h-16 text-white" />
              )}
            </div>
          </motion.div>

          <h2 className="text-2xl font-bold text-zinc-900 dark:text-zinc-50 mb-2">
            {locationName}
          </h2>
          <p
            className={`text-lg font-medium mb-12 ${
              isLocked
                ? "text-red-600 dark:text-red-400"
                : "text-green-600 dark:text-green-400"
            }`}
          >
            {isLocked ? "Locked" : "Unlocked"}
          </p>

          <div className="w-full space-y-4">
            <button
              onClick={handleLock}
              disabled={isLocked}
              className={`w-full py-5 rounded-2xl font-semibold text-lg shadow-sm transition-all ${
                isLocked
                  ? "bg-zinc-200 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-600 cursor-not-allowed"
                  : "bg-red-500 dark:bg-red-600 text-white hover:bg-red-600 dark:hover:bg-red-700 active:scale-98"
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <Lock className="w-5 h-5" />
                <span>Lock</span>
              </div>
            </button>

            <button
              onClick={handleUnlock}
              disabled={!isLocked}
              className={`w-full py-5 rounded-2xl font-semibold text-lg shadow-sm transition-all ${
                !isLocked
                  ? "bg-zinc-200 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-600 cursor-not-allowed"
                  : "bg-green-500 dark:bg-green-600 text-white hover:bg-green-600 dark:hover:bg-green-700 active:scale-98"
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <Unlock className="w-5 h-5" />
                <span>Unlock</span>
              </div>
            </button>
          </div>
        </div>

        <div className="p-6 text-center">
          <p className="text-sm text-zinc-500 dark:text-zinc-500">
            Demo app • Buttons are for demonstration only
          </p>
        </div>
      </div>
    </div>
  );
}
