
  # Smart Lock App

  This is a code bundle for Smart Lock App. The original project is available at https://www.figma.com/design/4NvSyCBBcRZzDvnBYQNMx0/Smart-Lock-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  